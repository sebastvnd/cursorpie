//! macOS hook: a `CGEventTap` on its own thread with a CoreFoundation run loop.
//!
//! [`spawn`] keeps retrying every 2 seconds until the Accessibility permission is granted. Native
//! events are translated by [`translate`] and routed by [`dispatch`].

use super::{Ev, Gesture, Kind, Verdict, dispatch, reset};
use crate::actions::SYNTH_TAG;
use crate::geometry::Point;
use crate::keys::{MOD_ALT, MOD_CMD, MOD_CTRL, MOD_SHIFT};
use crate::msg::Notifier;
use core_foundation::base::TCFType;
use core_foundation::mach_port::CFMachPortRef;
use core_foundation::runloop::{
    CFRunLoop, CFRunLoopRunResult, kCFRunLoopCommonModes, kCFRunLoopDefaultMode,
};
use core_graphics::event::{
    CGEvent, CGEventFlags, CGEventTap, CGEventTapLocation, CGEventTapOptions, CGEventTapPlacement,
    CGEventType, CallbackResult, EventField,
};
use core_graphics::geometry::CGPoint;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Duration;

/// The tap's mach port, kept so the callback can re-enable the tap after macOS disables it.
static TAP_PORT: AtomicUsize = AtomicUsize::new(0);

/// How often the run loop of the tap hands control back so the tap can be looked at. macOS sends
/// a "disabled" event when it turns a tap off, but only to a callback that is called: after a
/// sleep, a secure-input period or a timeout while nothing was pressed, nothing may ever call it.
const WATCHDOG: Duration = Duration::from_secs(2);

// Not exposed by the `core-graphics` crate.
unsafe extern "C" {
    fn CGEventTapEnable(tap: CFMachPortRef, enable: bool);
    fn CGEventTapIsEnabled(tap: CFMachPortRef) -> bool;
}

/// Converts event flags from a `CGEvent` into a `MOD_*` bitmask.
pub fn mods_from_flags(f: CGEventFlags) -> u8 {
    let mut m = 0;
    if f.contains(CGEventFlags::CGEventFlagShift) {
        m |= MOD_SHIFT;
    }
    if f.contains(CGEventFlags::CGEventFlagControl) {
        m |= MOD_CTRL;
    }
    if f.contains(CGEventFlags::CGEventFlagAlternate) {
        m |= MOD_ALT;
    }
    if f.contains(CGEventFlags::CGEventFlagCommand) {
        m |= MOD_CMD;
    }
    m
}

fn point(p: CGPoint) -> Point {
    Point::new(p.x, p.y)
}

// ------------------------------------------------------------------- startup

/// Starts the tap on its own thread and keeps retrying until the permission is granted.
pub fn spawn(notifier: Notifier) {
    std::thread::Builder::new()
        .name("cursorpie-tap".into())
        .spawn(move || {
            let state = Arc::new(Mutex::new(Gesture::Idle));
            // the trackpad source (idle until "touch_trigger" is switched on) shares the gesture
            super::touch::start(state.clone(), notifier.clone());
            let mut warned = false;
            loop {
                let (st, n) = (state.clone(), notifier.clone());
                let tap = CGEventTap::new(
                    CGEventTapLocation::HID,
                    CGEventTapPlacement::HeadInsertEventTap,
                    CGEventTapOptions::Default,
                    vec![
                        CGEventType::OtherMouseDown,
                        CGEventType::OtherMouseUp,
                        CGEventType::OtherMouseDragged,
                        CGEventType::RightMouseDown,
                        CGEventType::RightMouseUp,
                        CGEventType::RightMouseDragged,
                        // only the trackpad's extra click looks at the left button, and only while
                        // a trackpad pie is open (see `handle`: one atomic read otherwise)
                        CGEventType::LeftMouseDown,
                        CGEventType::LeftMouseUp,
                        CGEventType::LeftMouseDragged,
                        CGEventType::ScrollWheel,
                        CGEventType::KeyDown,
                        CGEventType::KeyUp,
                        // modifiers have no key events: their flags tell the order they were pressed in
                        CGEventType::FlagsChanged,
                    ],
                    move |_proxy, etype, event| guarded(&st, &n, etype, event),
                );

                match tap {
                    Ok(tap) => {
                        let Ok(source) = tap.mach_port().create_runloop_source(0) else {
                            std::thread::sleep(Duration::from_secs(2));
                            continue;
                        };
                        TAP_PORT.store(tap.mach_port().as_concrete_TypeRef() as usize, Ordering::SeqCst);
                        CFRunLoop::get_current().add_source(&source, unsafe { kCFRunLoopCommonModes });
                        tap.enable();
                        super::TAP_ACTIVE.store(true, Ordering::SeqCst);
                        diag::log!("tap", "hook", backend = "macos", state = "running");
                        notifier.wake();
                        watch(tap.mach_port().as_concrete_TypeRef(), &state, &notifier);
                        TAP_PORT.store(0, Ordering::SeqCst);
                        super::TAP_ACTIVE.store(false, Ordering::SeqCst);
                        diag::log!("tap", "hook", backend = "macos", state = "stopped");
                    }
                    Err(_) => {
                        super::TAP_ACTIVE.store(false, Ordering::SeqCst);
                        if !warned {
                            warned = true;
                            diag::log!("tap", "hook", backend = "macos", state = "blocked");
                            eprintln!(
                                "CursorPie: macOS blocked the event tap. Grant 'Accessibility' (and 'Input Monitoring') \
                                 to this app in System Settings -> Privacy & Security. Retrying every 2 s..."
                            );
                        }
                        notifier.wake();
                    }
                }
                std::thread::sleep(Duration::from_secs(2));
            }
        })
        .expect("failed to spawn event tap thread");
}

/// Runs the run loop of the tap in slices of [`WATCHDOG`] and, between them, makes sure macOS has
/// not turned the tap off. A tap that is off and cannot be turned on again is dead (its port is no
/// longer valid), so this returns and the caller builds a new one. Also returns when the run loop
/// ends.
///
/// `port` is the mach port of the tap, which the caller keeps alive for the whole call.
fn watch(port: CFMachPortRef, state: &Arc<Mutex<Gesture>>, notifier: &Notifier) {
    loop {
        // SAFETY: the default mode is part of the common modes the source was added to.
        let result = CFRunLoop::run_in_mode(unsafe { kCFRunLoopDefaultMode }, WATCHDOG, false);
        if matches!(
            result,
            CFRunLoopRunResult::Finished | CFRunLoopRunResult::Stopped
        ) {
            return;
        }
        // SAFETY: `port` belongs to the tap, which the caller keeps alive for the whole call.
        if unsafe { CGEventTapIsEnabled(port) } {
            continue;
        }
        // SAFETY: as above.
        unsafe { CGEventTapEnable(port, true) };
        // a press whose release the disabled tap never saw would leave the pie open
        reset(state, notifier);
        // SAFETY: as above.
        let back = unsafe { CGEventTapIsEnabled(port) };
        diag::log!(
            "tap",
            "hook",
            backend = "macos",
            state = "re_enabled",
            ok = back
        );
        if !back {
            return;
        }
    }
}

/// Runs the handler and turns a panic into "let the event through".
fn guarded(
    state: &Arc<Mutex<Gesture>>,
    n: &Notifier,
    t: CGEventType,
    e: &CGEvent,
) -> CallbackResult {
    std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| handle(state, n, t, e)))
        .unwrap_or(CallbackResult::Keep)
}

/// Converts a native event into the portable one. `None` for event types the tap does not use.
fn translate(etype: CGEventType, event: &CGEvent) -> Option<Ev> {
    let mouse = |kind: Kind, button: i64| Ev::Mouse {
        kind,
        button,
        pos: point(event.location()),
    };
    let other = |kind: Kind| {
        mouse(
            kind,
            event.get_integer_value_field(EventField::MOUSE_EVENT_BUTTON_NUMBER),
        )
    };
    Some(match etype {
        CGEventType::KeyDown | CGEventType::KeyUp => Ev::Key {
            down: matches!(etype, CGEventType::KeyDown),
            code: event.get_integer_value_field(EventField::KEYBOARD_EVENT_KEYCODE) as i32,
            mods: mods_from_flags(event.get_flags()),
        },
        CGEventType::RightMouseDown => mouse(Kind::Down, super::RIGHT_BUTTON),
        CGEventType::RightMouseUp => mouse(Kind::Up, super::RIGHT_BUTTON),
        CGEventType::RightMouseDragged => mouse(Kind::Drag, super::RIGHT_BUTTON),
        CGEventType::LeftMouseDown => mouse(Kind::Down, super::LEFT_BUTTON),
        CGEventType::LeftMouseUp => mouse(Kind::Up, super::LEFT_BUTTON),
        CGEventType::LeftMouseDragged => mouse(Kind::Drag, super::LEFT_BUTTON),
        CGEventType::OtherMouseDown => other(Kind::Down),
        CGEventType::OtherMouseUp => other(Kind::Up),
        CGEventType::OtherMouseDragged => other(Kind::Drag),
        _ => return None,
    })
}

/// The tap callback: decides what happens to one event (swallow = `Drop`, pass on = `Keep`).
fn handle(
    state: &Arc<Mutex<Gesture>>,
    notifier: &Notifier,
    etype: CGEventType,
    event: &CGEvent,
) -> CallbackResult {
    if matches!(
        etype,
        CGEventType::TapDisabledByTimeout | CGEventType::TapDisabledByUserInput
    ) {
        let port = TAP_PORT.load(Ordering::SeqCst);
        if port != 0 {
            unsafe { CGEventTapEnable(port as CFMachPortRef, true) };
        }
        reset(state, notifier);
        return CallbackResult::Keep;
    }
    // a modifier went down or up: only remembered (for the order of a recorded shortcut), never
    // touched
    if matches!(etype, CGEventType::FlagsChanged) {
        super::modorder::sync(mods_from_flags(event.get_flags()));
        return CallbackResult::Keep;
    }
    // the holding finger and the extra one are two fingers, which scroll: while a trackpad hold
    // runs that must not reach the app under the pie
    // (one atomic read for every scroll event)
    if matches!(etype, CGEventType::ScrollWheel) {
        return if super::touch::swallows_scroll() || super::pie_clicks::swallows_wheel(state) {
            CallbackResult::Drop
        } else {
            CallbackResult::Keep
        };
    }
    // a left click or drag is none of our business unless a pie is open: one atomic read and, for
    // a press, a try_lock that never waits
    let left = match etype {
        CGEventType::LeftMouseDown => Some(Kind::Down),
        CGEventType::LeftMouseUp => Some(Kind::Up),
        CGEventType::LeftMouseDragged => Some(Kind::Drag),
        _ => None,
    };
    if let Some(kind) = left
        && !super::touch::extra::interested(kind)
        && !super::pie_clicks::interested(state, kind)
    {
        return CallbackResult::Keep;
    }
    if event.get_integer_value_field(EventField::EVENT_SOURCE_USER_DATA) == SYNTH_TAG {
        return CallbackResult::Keep;
    }
    let Some(ev) = translate(etype, event) else {
        return CallbackResult::Keep;
    };
    // a press that turns out to be a real drag is handed back to the app, drag event included
    let replay_drag = || {
        let drag = event.clone();
        drag.set_integer_value_field(EventField::EVENT_SOURCE_USER_DATA, SYNTH_TAG);
        drag.post(CGEventTapLocation::HID);
    };
    match dispatch(state, notifier, ev, &replay_drag) {
        Verdict::Keep => CallbackResult::Keep,
        Verdict::Drop => CallbackResult::Drop,
    }
}
