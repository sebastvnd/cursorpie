//! Window management: showing the pie, opening/closing Settings, and the tray menu actions.

use super::{App, WIN_MARGIN, card_size_for, welcome_size_for};
use crate::config::{self, MAX_ITEMS, cfg};
use crate::platform;
use crate::side;
use crate::tap::PAUSED;
use crate::ui::screen::{PieHold, pie_hold, screen_rect_at};
use crate::ui::settings::{Tab, Welcome};
use eframe::egui::{self, Pos2, Vec2};
use std::sync::atomic::Ordering;
use std::time::{Duration, Instant};

/// Longest the card waits for the window to take its size (see [`App::window_settling`]).
const SETTLE_MAX: Duration = Duration::from_millis(300);

/// Whether a window of `size` (None = the system did not say) is the size `want`, give or take
/// the rounding to whole pixels. An unknown size counts as arrived: there is nothing to wait for.
fn has_size(size: Option<Vec2>, want: Vec2) -> bool {
    size.is_none_or(|s| (s.x - want.x).abs() <= 2.0 && (s.y - want.y).abs() <= 2.0)
}

impl App {
    /// Applies the edited config and writes it to disk (with a backup), without closing Settings:
    /// the config is sanitized and stored, and the launch-at-login setting is applied.
    pub fn persist_edit(&mut self) {
        let new = self.edit.clone().sanitize();
        let login = new.launch_at_login;
        *cfg() = new.clone();
        side::forget_all(); // a changed default should apply at once
        config::save_config_with_backup(&new);
        if let Err(e) = platform::set_launch_at_login(login) {
            eprintln!("CursorPie: could not update launch-at-login: {e}");
        }
        if let Some(t) = &self.tray {
            t.set_login_checked(login);
        }
    }

    /// Closes Settings and turns the window back into the hidden, click-through pie window.
    /// With `save`, the edited config is sanitized, stored, saved to disk and the launch-at-login setting is applied.
    pub fn close_settings(&mut self, ctx: &egui::Context, save: bool) {
        // how long closing took (saving is most of it) and whether the edits were kept
        let _t = diag::timed!("ui", "close_settings", save = save);
        self.ed.stop_recording();
        self.ed.scan = None;
        self.confirm_quit = false;
        self.confirm_discard = false;
        if save {
            self.persist_edit();
        }
        self.ed.icons.revalidate(); // re-read only the images that changed on disk
        self.release_editor(); // the next open copies the config again
        self.win = cfg().pie_size;
        self.set_settings_open(false);
        self.welcome = None;
        self.closing = None;
        self.settings_anim = 0.0;
        self.settings_wait = None;
        self.pie_open = false;
        self.anim = 0.0;
        self.visible = false;

        let w = crate::geometry::window_size(self.win);
        ctx.send_viewport_cmd(egui::ViewportCommand::InnerSize([w, w].into()));
        ctx.send_viewport_cmd(egui::ViewportCommand::MousePassthrough(true));
        ctx.send_viewport_cmd(egui::ViewportCommand::WindowLevel(
            egui::WindowLevel::AlwaysOnTop,
        ));
        self.hide_root(ctx);
        self.sleep_step(ctx); // the idle clock starts now
    }

    /// Brings the Settings (or welcome) window in front of everything: out of the minimized state,
    /// from behind other windows and from another desktop, workspace or Space. `why` names the
    /// reason for the diagnostic log.
    ///
    /// The toolkit's request is enough on macOS and Windows. On X11 the window manager refuses it
    /// while another program has the focus, so the platform asks again in its own way (see
    /// [`platform::raise_own_window`]).
    pub fn raise_settings(&self, ctx: &egui::Context, why: &'static str) {
        diag::log!(
            "ui",
            "raise_settings",
            why = why,
            visible = self.visible,
            welcome = self.welcome.is_some()
        );
        ctx.send_viewport_cmd(egui::ViewportCommand::Minimized(false));
        ctx.send_viewport_cmd(egui::ViewportCommand::Focus);
        platform::raise_own_window();
    }

    /// Whether the window is still on its way to the size the card was given. While it is, the
    /// caller draws nothing and returns, and the open animation has not started.
    ///
    /// The pie is a small window that is already on screen when a held trigger opens Settings
    /// (and a hidden one when the menu bar opens it). The commands that resize and move it are
    /// carried out by the system a moment after the frame that sent them, so the first frames of
    /// the card would be drawn into a window that still has the old size: the card cut off, or
    /// stretched when the window grows, and then a jump. Worst on the first open, when the
    /// frames are slowest (nothing is cached yet and the larger drawing surface is created).
    /// Drawing nothing keeps the transparent window empty until it has arrived.
    ///
    /// Only macOS needs this (the window there is resized while it is visible); elsewhere it is
    /// always false. A window that never reaches the size (the system clamped it) is let go of
    /// after `SETTLE_MAX`.
    pub fn window_settling(&mut self, ctx: &egui::Context) -> bool {
        let Some((want, since)) = self.settings_wait else {
            return false;
        };
        let size = ctx.input(|i| i.viewport().inner_rect).map(|r| r.size());
        if platform::OS != platform::Os::Mac
            || has_size(size, want)
            || since.elapsed() >= SETTLE_MAX
        {
            diag::log!(
                "ui",
                "window_settled",
                waited_ms = since.elapsed(),
                arrived = has_size(size, want)
            );
            self.settings_wait = None;
            ctx.request_repaint(); // draw the card now
            return false;
        }
        ctx.request_repaint_after(Duration::from_millis(8));
        true
    }

    /// Turns the window into Settings, centered on the display that contains `at`.
    pub(super) fn open_settings(&mut self, ctx: &egui::Context, at: Pos2, about: bool) {
        diag::log!(
            "ui",
            "open_settings",
            about = about,
            already_open = self.settings_open
        );
        if self.settings_open {
            self.raise_settings(ctx, "open_settings");
            if about {
                self.ed.tab = Tab::About;
            }
            return;
        }
        self.pie_open = false;
        self.set_settings_open(true);
        self.visible = true;
        self.closing = None;
        self.settings_anim = 0.0;
        self.ed.stop_recording();
        self.ed.scan = None;
        self.ed.icons.revalidate();
        self.ed.profile = 0;
        self.ed.reset_nav();
        self.ed.tab = if about { Tab::About } else { Tab::Menu };
        self.edit = cfg().clone();
        self.edit.launch_at_login = platform::launch_at_login_enabled();
        self.history.reset(&self.edit); // undo starts from what Settings opened with
        self.opened = Some(self.edit.clone()); // what "unsaved" is measured against

        let size = self.place_card_window(ctx, at, card_size_for);
        self.card_size = size;
    }

    /// Turns the window into the welcome window, centered on the display that contains `at`.
    /// Does nothing to a window that is already showing Settings or the welcome window except
    /// bring it to the front.
    pub(super) fn open_welcome(&mut self, ctx: &egui::Context, at: Pos2) {
        if self.settings_open {
            self.raise_settings(ctx, "open_welcome");
            return;
        }
        self.pie_open = false;
        self.set_settings_open(true);
        self.visible = true;
        self.closing = None;
        self.settings_anim = 0.0;
        self.ed.stop_recording();
        self.ed.scan = None;
        self.welcome = Some(Welcome::new(platform::launch_at_login_enabled()));
        self.card_size = self.place_card_window(ctx, at, welcome_size_for);
    }

    /// Shows the window as a normal, centered card on the display that contains `at`, `fit`
    /// deciding the card size from the size of that display. Returns the card size.
    fn place_card_window(&mut self, ctx: &egui::Context, at: Pos2, fit: fn(Vec2) -> Vec2) -> Vec2 {
        // centered on the display that contains the cursor
        let area = screen_rect_at(at)
            .unwrap_or_else(|| egui::Rect::from_center_size(at, egui::vec2(1600.0, 1000.0)));
        let card = fit(area.size());
        let win_sz = card + Vec2::splat(2.0 * WIN_MARGIN);
        let top_left = area.center() - win_sz / 2.0;
        diag::log!(
            "ui",
            "place_card",
            at_x = at.x,
            at_y = at.y,
            left = top_left.x,
            top = top_left.y,
            w = win_sz.x,
            h = win_sz.y
        );
        crate::debug::expect_window(top_left.x, top_left.y);
        self.settings_wait = Some((win_sz, Instant::now()));

        ctx.send_viewport_cmd(egui::ViewportCommand::InnerSize(win_sz));
        ctx.send_viewport_cmd(egui::ViewportCommand::Decorations(false));
        ctx.send_viewport_cmd(egui::ViewportCommand::MousePassthrough(false));
        ctx.send_viewport_cmd(egui::ViewportCommand::WindowLevel(
            egui::WindowLevel::Normal,
        ));
        ctx.send_viewport_cmd(egui::ViewportCommand::OuterPosition(top_left));
        ctx.send_viewport_cmd(egui::ViewportCommand::Visible(true));
        ctx.send_viewport_cmd(egui::ViewportCommand::Focus);
        // on X11 the toolkit drops that request until the window is mapped, and a window manager
        // may map it without the focus: ask again once it is listed
        platform::raise_own_window();
        card
    }

    /// Ends the welcome window once its close animation has finished: remembers that it was
    /// shown, applies the "Launch at login" box if the user went through to the end, and either
    /// hides the window or turns it into Settings (the "Open Settings" button).
    pub fn finish_welcome(&mut self, ctx: &egui::Context) {
        crate::config::mark_welcomed();
        let (apply, login, open_settings) = match &self.welcome {
            Some(w) => (w.apply, w.launch_at_login, w.open_settings_after),
            None => (false, false, false),
        };
        if apply && login != platform::launch_at_login_enabled() {
            match platform::set_launch_at_login(login) {
                Ok(()) => {
                    let snapshot = {
                        let mut c = cfg();
                        c.launch_at_login = login;
                        c.clone()
                    };
                    config::save_config(&snapshot);
                    if let Some(t) = &self.tray {
                        t.set_login_checked(login);
                    }
                }
                Err(e) => eprintln!("CursorPie: could not update launch-at-login: {e}"),
            }
        }
        if open_settings {
            // straight into Settings, without hiding the window in between
            self.welcome = None;
            self.set_settings_open(false);
            self.closing = None;
            let at = self.cursor_or_default();
            self.open_settings(ctx, at, false);
        } else {
            self.close_settings(ctx, false);
        }
    }

    /// Mirrors `settings_open` into [`tap::SETTINGS_OPEN`](crate::tap::SETTINGS_OPEN), which the
    /// tap thread reads to keep the pie off. Every change of `settings_open` goes through here.
    pub(super) fn set_settings_open(&mut self, open: bool) {
        self.settings_open = open;
        crate::tap::SETTINGS_OPEN.store(open, std::sync::atomic::Ordering::SeqCst);
    }

    /// The trigger was pressed while Settings is open, so the pie did not open. Settings may be
    /// behind other windows, minimized or on another desktop: without a sign the press looks like it
    /// did nothing. Brings the window forward and says why.
    pub(super) fn pie_blocked(&mut self, ctx: &egui::Context, _x: f64, _y: f64) {
        // (not while a file chooser is open: it would end up under Settings)
        if !crate::ui::settings::choosing() {
            self.raise_settings(ctx, "pie_press");
            ctx.send_viewport_cmd(egui::ViewportCommand::RequestUserAttention(
                egui::UserAttentionType::Informational,
            ));
        }
        self.say("The pie is off while Settings is open  \u{b7}  Save or Cancel to use it again");
    }

    /// Opens the pie window for `profile` at (x, y). Submenus call this again to re-center.
    pub(super) fn show_pie(
        &mut self,
        ctx: &egui::Context,
        x: f64,
        y: f64,
        profile: usize,
        path: Vec<usize>,
    ) {
        if self.settings_open {
            // defense in depth: the tap does not ask for a pie while Settings is open
            diag::log!(
                "ui",
                "show_pie_ignored",
                reason = "settings_open",
                x = x,
                y = y
            );
            self.pie_blocked(ctx, x, y);
            return;
        }
        self.win = cfg().pie_size;
        self.profile = profile;
        self.path = path;
        self.hover = None;
        self.hover_anim = [0.0; MAX_ITEMS];
        self.badge_in = [0.0; MAX_ITEMS];
        self.badge_pick = [[0.0; 2]; MAX_ITEMS];
        self.badge_step = [[0.0; 2]; MAX_ITEMS];
        self.pie_open = true;
        self.fresh = true;
        self.anim = 0.0; // submenus "bloom" again, re-centered on the cursor
        self.opened_at = Instant::now();
        self.pie_pos = egui::pos2(x as f32, y as f32);

        let w = crate::geometry::window_size(self.win);
        ctx.send_viewport_cmd(egui::ViewportCommand::InnerSize([w, w].into()));
        ctx.send_viewport_cmd(egui::ViewportCommand::Decorations(false));
        // A mouse hold has a button down, so the apps under the pie hear no pointer motion. A
        // trackpad hold has none: the finger moves the real pointer, and a click-through pie lets
        // every move reach the page below (a video player shows its controls, links highlight).
        // So the pie of a trackpad hold takes the pointer; the pie follows the cursor, so the
        // pointer stays inside it. Clicks are swallowed by the taps as before.
        let takes_pointer = crate::tap::touch_pie_active();
        diag::log!("ui", "pie_input", takes_pointer = takes_pointer);
        ctx.send_viewport_cmd(egui::ViewportCommand::MousePassthrough(!takes_pointer));
        ctx.send_viewport_cmd(egui::ViewportCommand::WindowLevel(
            egui::WindowLevel::AlwaysOnTop,
        ));
        // whole points: a window on a half-point offset is resampled by the compositor on
        // standard-density screens, which softens everything drawn in it
        let top_left = egui::pos2((x as f32 - w / 2.0).round(), (y as f32 - w / 2.0).round());
        diag::log!(
            "ui",
            "show_pie",
            x = x,
            y = y,
            win = w,
            left = top_left.x,
            top = top_left.y,
            ppp = ctx.pixels_per_point(),
            visible_before = self.visible,
            mon = screen_rect_at(self.pie_pos).map_or_else(String::new, |r| {
                diag::rect_str(
                    f64::from(r.min.x),
                    f64::from(r.min.y),
                    f64::from(r.width()),
                    f64::from(r.height()),
                )
            })
        );
        crate::debug::expect_window(top_left.x, top_left.y);
        ctx.send_viewport_cmd(egui::ViewportCommand::OuterPosition(top_left));
        if !self.visible {
            self.visible = true;
            ctx.send_viewport_cmd(egui::ViewportCommand::Visible(true));
        }
        if platform::window_manager_may_recenter() {
            // Once mapped, a move is a request from the client and the window manager honors
            // it; the position given while the window was hidden is not always kept.
            ctx.send_viewport_cmd(egui::ViewportCommand::OuterPosition(top_left));
            self.want_pos = Some((top_left, Instant::now()));
            ctx.request_repaint();
        }
    }

    /// For a short time after the pie was shown, moves the window back to where it was asked to
    /// be if the window manager put it somewhere else (see [`App::want_pos`]).
    pub(super) fn enforce_pie_pos(&mut self, ctx: &egui::Context) {
        const HOLD: Duration = Duration::from_millis(300);
        let Some((target, since)) = self.want_pos else {
            return;
        };
        if self.settings_open || !self.pie_open {
            self.want_pos = None;
            return;
        }
        let outer_min = ctx.input(|i| i.viewport().outer_rect).map(|r| r.min);
        match pie_hold(target, outer_min, since.elapsed(), HOLD) {
            PieHold::Release => {
                self.want_pos = None;
                return;
            }
            PieHold::Move => {
                ctx.send_viewport_cmd(egui::ViewportCommand::OuterPosition(target));
            }
            PieHold::Keep => {}
        }
        ctx.request_repaint_after(Duration::from_millis(16));
    }

    /// Menu bar item: switch which pie the side buttons follow in the app in front.
    fn swap_side(&mut self, ctx: &egui::Context) {
        let bundle = platform::frontmost_bundle_id();
        let (switched, general, ms) = {
            let c = cfg();
            (
                side::toggle(&c, bundle.as_deref()),
                c.global_profile(),
                c.preview_ms,
            )
        };
        // an app without a pie of its own has nothing to switch: just show the one pie there is
        let profile = switched.unwrap_or(general);
        if ms == 0 {
            return;
        }
        let at = self.cursor_or_default();
        let center = screen_rect_at(at).map_or(at, |r| r.center());
        self.show_pie(ctx, center.x as f64, center.y as f64, profile, Vec::new());
        self.preview_until = Some(Instant::now() + Duration::from_millis(ms));
        // the ring colors are computed for the app the last gesture was about
        side::set_target(bundle, false);
    }

    /// Current cursor position, or a fixed fallback if the OS cannot tell.
    pub(super) fn cursor_or_default(&self) -> Pos2 {
        let raw = platform::pointer_pos();
        diag::log!(
            "ui",
            "cursor_or_default",
            ok = raw.is_some(),
            x = raw.map_or(400.0, |p| p.0),
            y = raw.map_or(300.0, |p| p.1)
        );
        raw.map(|(x, y)| egui::pos2(x as f32, y as f32))
            .unwrap_or(egui::pos2(400.0, 300.0))
    }

    /// Quits the app. The close request may never be processed while the window is hidden, so a
    /// short-lived thread exits the process as a fallback.
    pub fn quit(&mut self, ctx: &egui::Context) {
        self.quitting = true;
        ctx.send_viewport_cmd(egui::ViewportCommand::Close);
        std::thread::spawn(|| {
            std::thread::sleep(Duration::from_millis(1500));
            std::process::exit(0);
        });
    }

    /// Handles a menu bar item click by its id (see `ui::tray`).
    pub(super) fn handle_tray(&mut self, ctx: &egui::Context, id: &str) {
        match id {
            "settings" => {
                let at = self.cursor_or_default();
                self.open_settings(ctx, at, false);
            }
            "about" => {
                let at = self.cursor_or_default();
                self.open_settings(ctx, at, true);
            }
            "welcome" => {
                let at = self.cursor_or_default();
                self.open_welcome(ctx, at);
            }
            "swap_side" => self.swap_side(ctx),
            "pause" => {
                if let Some(t) = &self.tray {
                    PAUSED.store(t.pause_checked(), Ordering::SeqCst);
                }
            }
            "login" => {
                if let Some(t) = &self.tray
                    && let Err(e) = platform::set_launch_at_login(t.login_checked())
                {
                    eprintln!("CursorPie: could not update launch-at-login: {e}");
                }
            }
            "quit" => self.request_quit(ctx),
            _ => {}
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_window_has_arrived_when_it_has_the_size_asked_for() {
        let want = Vec2::new(1260.0, 820.0);
        assert!(has_size(Some(Vec2::new(1260.0, 820.0)), want));
        assert!(
            has_size(Some(Vec2::new(1259.0, 821.0)), want),
            "pixel rounding"
        );
        assert!(
            !has_size(Some(Vec2::new(400.0, 400.0)), want),
            "still the pie"
        );
        assert!(!has_size(Some(Vec2::new(1260.0, 400.0)), want));
        assert!(has_size(None, want), "nothing to compare: do not wait");
    }
}
