//! Applies one [`Msg`] (sent by the event tap, the tray menu or a file-picker thread) to the UI state.

use super::App;
use crate::config::flow::{add_flow, import_flow_file, merge_flows};
use crate::config::share::{add_profile, import_file_with_flows};
use crate::config::{
    Action, Flow, ItemKind, MAX_CONFIG_FILE_BYTES, NodeKind, cfg, has_commands, icons_dir,
    item_at_mut, parse_config, profile_has_commands, read_text_capped, tilde,
};
use crate::msg::Msg;
use crate::platform;
use crate::ui::appicon;
use crate::ui::settings::Slot;
use eframe::egui;
use std::time::{Duration, Instant};

impl App {
    /// Applies one message. Anything that touches the config edits the Settings *copy* (`self.edit`).
    pub(super) fn handle_msg(&mut self, ctx: &egui::Context, msg: Msg) {
        match msg {
            Msg::ShowPie {
                x,
                y,
                profile,
                path,
            } => {
                // a real gesture takes over from any preview
                self.preview_until = None;
                diag::log!(
                    "ui",
                    "msg_show_pie",
                    x = x,
                    y = y,
                    profile = profile,
                    depth = path.len()
                );
                self.show_pie(ctx, x, y, profile, path);
            }
            Msg::PieBlocked { x, y } => self.pie_blocked(ctx, x, y),
            Msg::OpenSettings { x, y, about } => {
                self.open_settings(ctx, egui::pos2(x as f32, y as f32), about);
            }
            Msg::OpenWelcome { x, y } => self.open_welcome(ctx, egui::pos2(x as f32, y as f32)),
            Msg::Hover(h) => {
                if h.is_some()
                    && h != self.hover
                    && self.last_tick.elapsed() > Duration::from_millis(60)
                    && cfg().sound
                {
                    platform::tick();
                    self.last_tick = Instant::now();
                }
                self.hover = h;
            }
            Msg::Haptic(kind) => {
                platform::haptic(kind);
                #[cfg(feature = "vtrackpad")]
                self.vt_cue(ctx, crate::ui::vtrackpad::Cue::Tick(kind));
            }
            Msg::NewProfileAppPicked(bundle) => self.ed.new_profile_app = bundle,
            Msg::InstalledApps(apps) => {
                self.ed.installed = apps;
                self.ed.installed_scan = crate::ui::settings::AppScan::Done;
            }
            Msg::ProfileImportPicked(file) => self.import_profile(&file),
            Msg::FlowImportPicked(file) => self.import_flow(&file),
            Msg::Notice(text) => self.say(text),
            Msg::MouseChanged { new, name, extra } => {
                let which = if new { "New mouse" } else { "Mouse back again" };
                self.say(format!("{which}: {name} ({extra} extra buttons)"));
            }
            Msg::ButtonScanned(button) => {
                if let Some(scan) = self.ed.scan.as_mut() {
                    scan.press(button);
                }
            }
            Msg::Warm { general, app } => self.warm(ctx, general, app),
            Msg::Refocus => {
                if self.settings_open {
                    self.raise_settings(ctx, "chooser_closed");
                }
            }
            Msg::HidePie => {
                diag::log!(
                    "ui",
                    "hide_pie",
                    was_open = self.pie_open,
                    was_visible = self.visible
                );
                self.hover = None;
                self.pie_open = false;
                self.preview_until = None;
                // the pie that took the pointer for a trackpad hold lets it through again while it fades
                ctx.send_viewport_cmd(egui::ViewportCommand::MousePassthrough(true));
            }
            Msg::KeyCaptured(sc) => {
                // a shortcut block of the Flow tab, or a field of a slice of the Menu tab
                let flow_block = self.ed.recording.as_ref().and_then(|r| match r.slot {
                    Slot::Node(id) => Some((r.profile, id)),
                    _ => None,
                });
                if let Some((flow, id)) = flow_block {
                    self.ed.recording = None;
                    if let Some(f) = self.edit.flows.get_mut(flow)
                        && let Some(n) = f.node_mut(id)
                        && let NodeKind::Key(k) = &mut n.kind
                    {
                        *k = sc;
                    }
                } else if let Some(rec) = self.ed.recording.take()
                    && let Some(p) = self.edit.profiles.get_mut(rec.profile)
                    && let Some(item) = item_at_mut(&mut p.items, &rec.path)
                {
                    match (&mut item.kind, rec.slot) {
                        (ItemKind::Mode { back, .. }, Slot::Back) => *back = Action::Key(sc),
                        (ItemKind::Mode { forward, .. }, Slot::Forward) => {
                            *forward = Action::Key(sc)
                        }
                        (ItemKind::Mode { extra, .. }, Slot::Extra(b)) => {
                            extra.insert(b, Action::Key(sc));
                        }
                        (ItemKind::Run(a), Slot::Run) => *a = Action::Key(sc),
                        _ => {}
                    }
                }
            }
            Msg::RecordCancelled => self.ed.recording = None,
            Msg::IconPicked {
                profile,
                path,
                file,
                note,
            } => {
                if let Some(p) = self.edit.profiles.get_mut(profile)
                    && let Some(item) = item_at_mut(&mut p.items, &path)
                {
                    item.icon = file;
                }
                if let Some(note) = note {
                    self.say(note);
                }
            }
            Msg::AppPicked { profile, bundle } => {
                if let Some(p) = self.edit.profiles.get_mut(profile)
                    && !p.apps.contains(&bundle)
                {
                    p.apps.push(bundle);
                }
            }
            // streamed with a size cap: a wrong file is never read whole into memory
            Msg::ImportPicked(file) => match read_text_capped(&file, MAX_CONFIG_FILE_BYTES)
                .and_then(|t| parse_config(&t))
            {
                Some(cfg_in) => {
                    let warn = has_commands(&cfg_in);
                    diag::log!(
                        "ui",
                        "import_config",
                        ok = true,
                        profiles = cfg_in.profiles.len(),
                        has_commands = warn
                    );
                    self.edit = cfg_in;
                    self.ed.profile = 0;
                    self.ed.reset_nav();
                    self.ed.stop_recording();
                    self.ed.icons.revalidate();
                    self.say(if warn {
                        "Imported. This config runs shell commands - review them before you Save."
                    } else {
                        "Imported. Review it, then press Save to apply."
                    });
                }
                None => {
                    diag::log!("ui", "import_config", ok = false);
                    self.say("That file is not a valid CursorPie config.")
                }
            },
            Msg::Tray(id) => self.handle_tray(ctx, &id),
            Msg::FlowAppPicked { flow, node, app } => {
                if let Some(n) = self
                    .edit
                    .flows
                    .get_mut(flow)
                    .and_then(|f| f.nodes.iter_mut().find(|n| n.id == node))
                    && matches!(n.kind, NodeKind::OpenApp(_))
                {
                    n.kind = NodeKind::OpenApp(app);
                }
            }
            Msg::ActionAppPicked {
                profile,
                path,
                slot,
                app,
            } => {
                // the icon of the picked app, for a slice that already shows an app's icon or
                // still has the icon a new "Open app" slice starts with
                let app_id = appicon::app_id_for_action(&app, &self.ed.installed);
                if let Some(p) = self.edit.profiles.get_mut(profile)
                    && let Some(item) = item_at_mut(&mut p.items, &path)
                {
                    match (&mut item.kind, slot) {
                        (ItemKind::Mode { extra, .. }, Slot::Extra(b)) => {
                            extra.insert(b, Action::OpenApp(app));
                        }
                        (ItemKind::Run(a), Slot::Run) => {
                            *a = Action::OpenApp(app);
                            let tone = match appicon::parse_slice(&item.icon) {
                                Some((tone, _)) => Some(tone),
                                None if appicon::is_placeholder_icon(&item.icon) => {
                                    Some(appicon::SliceTone::Color)
                                }
                                None => None,
                            };
                            if let (Some(tone), Some(id)) = (tone, app_id) {
                                item.icon = appicon::slice_icon_string(tone, &id);
                            }
                        }
                        (ItemKind::Mode { back, .. }, Slot::Back) => *back = Action::OpenApp(app),
                        (ItemKind::Mode { forward, .. }, Slot::Forward) => {
                            *forward = Action::OpenApp(app)
                        }
                        _ => {}
                    }
                }
            }
        }
    }
}

impl App {
    /// Adds the profile in `file` (with its icons) to the Settings copy as a new profile.
    fn import_profile(&mut self, file: &str) {
        if !self.settings_open {
            return; // the chooser answered after Settings was closed
        }
        // the flows the profile uses come with it; if the profile cannot be added after all, the
        // flows are taken out again
        let flows_before = self.edit.flows.clone();
        let added =
            import_file_with_flows(file, &icons_dir(), &tilde).and_then(|(mut p, flows)| {
                let runs_commands =
                    profile_has_commands(&p) || flows.iter().any(Flow::has_commands);
                merge_flows(&mut self.edit.flows, flows, &mut p.items)?;
                add_profile(&mut self.edit, p).map(|i| (i, runs_commands))
            });
        if added.is_err() {
            self.edit.flows = flows_before;
        }
        match added {
            Ok((index, runs_commands)) => {
                self.ed.profile = index;
                self.ed.reset_nav();
                self.ed.stop_recording();
                self.ed.icons.revalidate();
                self.say(if runs_commands {
                    "Profile imported. It runs shell commands - review them before you Save."
                } else {
                    "Profile imported. Review it, then press Save to apply."
                });
            }
            Err(e) => self.say(e),
        }
    }

    /// Adds the flow in `file` to the Settings copy as a new flow.
    fn import_flow(&mut self, file: &str) {
        if !self.settings_open {
            return; // the chooser answered after Settings was closed
        }
        let added = import_flow_file(file).and_then(|f| {
            let runs_commands = f.has_commands();
            add_flow(&mut self.edit.flows, f).map(|i| (i, runs_commands))
        });
        match added {
            Ok((index, runs_commands)) => {
                self.ed.flow = index;
                self.ed.flow_sel = None;
                self.ed.flow_wire = None;
                self.ed.flow_pan = egui::Vec2::ZERO;
                self.ed.stop_recording();
                self.say(if runs_commands {
                    "Flow imported. It runs shell commands - review them before you Save."
                } else {
                    "Flow imported. Review it, then press Save to apply."
                });
            }
            Err(e) => self.say(e),
        }
    }
}
